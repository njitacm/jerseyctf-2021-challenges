# open-creds
API in Something
* Something is Discord

## Purpose
* To `API` in Discord
  * Ah yes, API. Hmmmm

## Usage
prob `python3 src/app.py`

## Technical Limitations
* Not enough [MOV Instructions](https://github.com/xoreaxeaxeax/movfuscator)

## Class
* Mr. Casyn's OSINT Class

## Author
Tess Qing
